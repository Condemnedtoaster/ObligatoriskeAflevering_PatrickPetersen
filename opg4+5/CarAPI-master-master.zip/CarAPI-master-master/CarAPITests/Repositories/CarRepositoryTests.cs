﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using CarAPI.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarAPI.Repositories.Tests
{
    [TestClass()]
    public class CarRepositoryTests
    {

        [TestMethod()]
        public void GetAllTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void AddTest()
        {
            Assert.Fail();
        }
    }
}